export const Pokedex: import('../../../sim/dex-species').ModdedSpeciesDataTable = {
	tyranitarmega: {
		inherit: true,
		baseStats: { hp: 100, atk: 164, def: 160, spa: 75, spd: 120, spe: 81 },
		abilities: { 0: "Stamina" },
	},
	falinksmega: {
		inherit: true,
		baseStats: { hp: 65, atk: 125, def: 120, spa: 75, spd: 75, spe: 110 },
		abilities: { 0: "Brass Bond" },
	},
	abomasnowmega: {
		inherit: true,
		baseStats: { hp: 90, atk: 132, def: 95, spa: 132, spd: 85, spe: 60 },
		abilities: { 0: "Ice Scales" },
	},
	dianciemega: {
		inherit: true,
		baseStats: { hp: 50, atk: 150, def: 125, spa: 150, spd: 125, spe: 100 },
		abilities: { 0: "Rocky Payload" },
	},
	mewtwomegax: {
		inherit: true,
		baseStats: { hp: 106, atk: 120, def: 135, spa: 154, spd: 135, spe: 130 },
		abilities: { 0: "Pure Power" },
	},
	mewtwomegay: {
		inherit: true,
		baseStats: { hp: 106, atk: 104, def: 120, spa: 180, spd: 120, spe: 150 },
		abilities: { 0: "Dark Aura" },
		types: ["Psychic", "Dark"],
	},
	emboarmega: {
		inherit: true,
		baseStats: { hp: 110, atk: 138, def: 75, spa: 135, spd: 95, spe: 75 },
		abilities: { 0: "Neuroforce" },
	},
	ampharosmega: {
		inherit: true,
		baseStats: { hp: 90, atk: 75, def: 100, spa: 155, spd: 130, spe: 55 },
		abilities: { 0: "Fluffy" },
	},
	garchompmega: {
		inherit: true,
		baseStats: { hp: 108, atk: 160, def: 125, spa: 75, spd: 100, spe: 132 },
		abilities: { 0: "Hustle" },
	},
	tatsugiricurlymega: {
		inherit: true,
		baseStats: { hp: 68, atk: 75, def: 90, spa: 135, spd: 125, spe: 92 },
		abilities: { 0: "Supreme Overlord" },
	},
	raichumegax: {
		inherit: true,
		baseStats: { hp: 60, atk: 115, def: 95, spa: 115, spd: 100, spe: 100 },
		abilities: { 0: "Electromorphosis" },
	},
	zeraoramega: {
		inherit: true,
		baseStats: { hp: 88, atk: 157, def: 85, spa: 117, spd: 90, spe: 158 },
		abilities: { 0: "Transistor" },
		types: ["Electric", "Dark"],
	},
	scolipedemega: {
		inherit: true,
		abilities: { 0: "Steely Spirit" },
	},
	absolmega: {
		inherit: true,
		baseStats: { hp: 65, atk: 140, def: 90, spa: 85, spd: 90, spe: 95 },
		abilities: { 0: "Tablets of Ruin" },
		types: ["Dark", "Normal"],
	},
	absolmegaz: {
		inherit: true,
		baseStats: { hp: 65, atk: 155, def: 80, spa: 100, spd: 80, spe: 85 },
		abilities: { 0: "Moxie" },
	},
	skarmorymega: {
		inherit: true,
		baseStats: { hp: 65, atk: 125, def: 125, spa: 60, spd: 90, spe: 100 },
		abilities: { 0: "Good as Gold" },
	},
	chandeluremega: {
		inherit: true,
		baseStats: { hp: 60, atk: 60, def: 125, spa: 175, spd: 125, spe: 75 },
		abilities: { 0: "Neutralizing Gas" },
	},
	slowbromega: {
		inherit: true,
		baseStats: { hp: 95, atk: 85, def: 150, spa: 110, spd: 120, spe: 30 },
		abilities: { 0: "Unaware" },
	},
	alakazammega: {
		inherit: true,
		baseStats: { hp: 55, atk: 60, def: 60, spa: 150, spd: 125, spe: 150 },
		abilities: { 0: "Psychic Surge" },
	},
	chesnaughtmega: {
		inherit: true,
		baseStats: { hp: 88, atk: 132, def: 167, spa: 104, spd: 108, spe: 31 },
		abilities: { 0: "Grassy Surge" },
	},
	golurkmega: {
		inherit: true,
		baseStats: { hp: 89, atk: 148, def: 90, spa: 51, spd: 90, spe: 115 },
		abilities: { 0: "No Guard" },
	},
	drampamega: {
		inherit: true,
		baseStats: { hp: 78, atk: 70, def: 120, spa: 155, spd: 121, spe: 46 },
		abilities: { 0: "Fluffy" },
	},
	zaciancrowned: {
		inherit: true,
		baseStats: { hp: 92, atk: 160, def: 115, spa: 80, spd: 115, spe: 148 },
	},
	zamazentacrowned: {
		inherit: true,
		baseStats: { hp: 92, atk: 120, def: 145, spa: 80, spd: 145, spe: 128 },
	},
	gengarmega: {
		inherit: true,
		abilities: { 0: "Merciless" },
	},
	excadrillmega: {
		inherit: true,
		abilities: { 0: "Iron Barbs" },
	},
	audinomega: {
		inherit: true,
		abilities: { 0: "Regenerator" },
	},
};
